﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media;
using FontAwesome.Sharp;
using tugas_sbd.Forms;
using Color = System.Drawing.Color;

namespace tugas_sbd
{
    public partial class Form1 : Form
    {
        //fields
        private IconButton currentbtn;
        private Panel leftBorderbtn;
        private Form currentChildForm; 
        public Form1()
        {
            InitializeComponent();
            leftBorderbtn = new Panel();
            leftBorderbtn.Size = new Size(7, 60);
            ActivateButton(iconButton1, RGBColors.color1);
            OpenChildForm(new FormClient());
            //form
            this.Text = String.Empty;
            this.DoubleBuffered = true;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
        }

        //Struct
        private struct RGBColors
        {
            public static Color color1 = Color.FromArgb(82, 195, 197);
            public static Color color2 = Color.FromArgb(136, 199, 176);
            public static Color color3 = Color.FromArgb(208, 218, 98);
            public static Color color4 = Color.FromArgb(238, 209, 100);
            public static Color color5 = Color.FromArgb(234, 171, 96);
            public static Color color6 = Color.FromArgb(230, 140, 150);
            public static Color color7 = Color.FromArgb(245, 216, 224);
            public static Color color8 = Color.FromArgb(176, 144, 189);
        }
        
        //Methods
        private void ActivateButton(object senderBtn,Color color)
        {
            if(senderBtn != null)
            {
                DisableButton();
                //button
                currentbtn = (IconButton)senderBtn;
                currentbtn.BackColor = Color.FromArgb(61, 44, 120);
                currentbtn.ForeColor = color;
                currentbtn.TextAlign = ContentAlignment.MiddleCenter;
                currentbtn.IconColor = color;
                currentbtn.TextImageRelation = TextImageRelation.TextBeforeImage;
                currentbtn.ImageAlign = ContentAlignment.MiddleRight;
                //left border button
                leftBorderbtn.BackColor = color;
                leftBorderbtn.Location = new Point(0, currentbtn.Location.Y);
                leftBorderbtn.Visible = true;
                leftBorderbtn.BringToFront();
                //icon current
                current.IconChar = currentbtn.IconChar;
                current.IconColor = color;
                titleCurrent.Text = currentbtn.Text;
            }
        }
        
        private void DisableButton()
        {
            if(currentbtn != null)
            {
                currentbtn.BackColor = Color.FromArgb(49, 35, 99);
                currentbtn.ForeColor = Color.Gainsboro;
                currentbtn.TextAlign = ContentAlignment.MiddleLeft;
                currentbtn.IconColor = Color.Gainsboro;
                currentbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentbtn.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }

        private void OpenChildForm(Form childform)
        {
            if(currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            paneldesktop.Controls.Add(childform);
            paneldesktop.Tag = childform;
            childform.BringToFront();
            childform.Show();
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color1);
            OpenChildForm(new FormClient());
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color2);
            OpenChildForm(new FormInstructor());
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color3);
            OpenChildForm(new FormClass());
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color4);
            OpenChildForm(new FormRoom());
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color5);
            OpenChildForm(new FormEnrolls());
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color6);
            OpenChildForm(new FormMembership());
        }

        private void iconButton7_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color7);
            OpenChildForm(new FormPayment());
        }
        private void iconButton8_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColors.color8);
        }
       
    
     

     
    }
}
